== Credits ==

This plugin is based on ThemeTrust Google Fonts Plugin: https://themetrust.com/plugin/google-fonts/

License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html